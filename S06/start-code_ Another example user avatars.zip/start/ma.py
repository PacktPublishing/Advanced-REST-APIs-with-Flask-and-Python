from flask_marshmallow import Marshmallow

ma = Marshmallow()
